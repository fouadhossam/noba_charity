<?php

interface iSort{
    public function sort($direction);
}

?>