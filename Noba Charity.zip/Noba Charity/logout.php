<?php
include_once "Classes.php";
$user = new User();
$user->logout();
?>
