<?php

interface iOperation {
    public function viewDonationDetails();
    public function viewDonationTypes();
}

?>
